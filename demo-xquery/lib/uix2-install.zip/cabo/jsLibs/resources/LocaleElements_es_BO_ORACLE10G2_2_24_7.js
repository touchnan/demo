var LocaleSymbols_es_BO = new LocaleSymbols({
DayNames:["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], 
DayAbbreviations:["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], 
DateTimeElements:["2", "1"], 
MonthNames:["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], 
DateTimePatterns:["hh:mm:ss a z", "hh:mm:ss a z", "hh:mm:ss a", "hh:mm a", "EEEE d\x27 de \x27MMMM\x27 de \x27yyyy", "d\x27 de \x27MMMM\x27 de \x27yyyy", "dd-MM-yyyy", "dd-MM-yy", "{1} {0}"], 
NumberElements:[".", ",", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
AmPmMarkers:["AM", "PM"], 
Eras:["BC", "AD"], 
MonthAbbreviations:["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});
