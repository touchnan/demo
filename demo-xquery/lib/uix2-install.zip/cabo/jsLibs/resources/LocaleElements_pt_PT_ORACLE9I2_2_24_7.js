var LocaleSymbols_pt_PT = new LocaleSymbols({
DayNames:["domingo", "segunda-feira", "ter\xe7a-feira", "quarta-feira", "quinta-feira", "sexta-feira", "s\xe1bado"], 
DayAbbreviations:["dom", "seg", "ter", "qua", "qui", "sex", "sab"], 
DateTimeElements:["2", "4"], 
MonthNames:["Janeiro", "Fevereiro", "Mar\xe7o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"], 
DateTimePatterns:["HH\x27H\x27mm\x27m\x27 z", "H:mm:ss z", "H:mm:ss", "H:mm", "EEEE, d\x27 de \x27MMMM\x27 de \x27yyyy", "d\x27 de \x27MMMM\x27 de \x27yyyy", "d/MMM/yyyy", "dd-MM-yyyy", "{1} {0}"], 
NumberElements:[",", ".", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
AmPmMarkers:["AM", "PM"], 
Eras:["BC", "AD"], 
MonthAbbreviations:["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
});
