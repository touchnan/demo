var LocaleSymbols_es_ES = new LocaleSymbols({
DayNames:["Domingo", "Lunes", "Martes", "Mi\xe9rcoles", "Jueves", "Viernes", "S\xe1bado"], 
DayAbbreviations:["Dom", "Lun", "Mar", "Mi\xe9", "Jue", "Vie", "S\xe1b"], 
DateTimeElements:["2", "4"], 
MonthNames:["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"], 
DateTimePatterns:["HH\x27H\x27mm\x27\x27 z", "H:mm:ss z", "H:mm:ss", "H:mm", "EEEE d\x27 de \x27MMMM\x27 de \x27yyyy", "d\x27 de \x27MMMM\x27 de \x27yyyy", "dd-MMM-yyyy", "d/MM/yy", "{1} {0}"], 
NumberElements:[",", ".", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"], 
AmPmMarkers:["AM", "PM"], 
Eras:["BC", "AD"], 
MonthAbbreviations:["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]
});
